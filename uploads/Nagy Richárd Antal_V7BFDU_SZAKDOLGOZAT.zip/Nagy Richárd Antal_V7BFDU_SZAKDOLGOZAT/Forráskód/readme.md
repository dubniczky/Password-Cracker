# Titkosított Jelszavak Feltörésének Gyorsítása GPU Parallelizációval

Nagy Richárd Antal